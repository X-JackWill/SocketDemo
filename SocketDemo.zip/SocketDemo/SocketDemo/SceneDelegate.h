//
//  SceneDelegate.h
//  SocketDemo
//
//  Created by Morris on 2021/9/23.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

